# seatbelt detection > 2023-05-01 2:34pm
https://universe.roboflow.com/machine-learning-nqku8/seatbelt-detection-2k7mo

Provided by a Roboflow user
License: CC BY 4.0

